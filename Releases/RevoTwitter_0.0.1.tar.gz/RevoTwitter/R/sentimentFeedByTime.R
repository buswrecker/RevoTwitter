#
# Copyright (c) 2011, 2012, Revolution Analytics. All rights reserved.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#' Update Twitter Feed from XDF
#' 
#' This function will take in an string of the XDF file location and return TRUE if 
#' successfully updated twitterFeeds
#'
#' @param TwitterXdf A string of the XDF file 
#' @param N Number of initialize feeds to populate the XDF
#'
#' @return Boolean. TRUE if update from twitter is successful, FALSE otherwise
#' 
#' @seealso \code{\link{initializeFeed}}
#' 
#' @author Julian Lee \email{julian.lee@@revolutionanalytics.com}



sentimentFeedByTime <- function(searchString,startDate, endDate, window=100, timeframe='hour'){
  
  require(ggplot2)
  
  ##Prepare the TableName
  tableName <- gsub('@*#*','',searchString)
  
  ##Grab the Data
  m <- dbDriver("SQLite")
  con <- dbConnect(m, dbname = options('revoSQLiteFile')[[1]])
  
  SQLstatement <- paste('SELECT created,score from ',tableName,
                        ' WHERE created BETWEEN "',
                        startDate, '" AND "', endDate, '"', sep='')
  
  tweetData <- dbGetQuery(con, SQLstatement)
  
  dbDisconnect(con)
  
  tweetData$created <- trunc(as.POSIXct(tweetData$created,tz='Singapore'),timeframe)
  
  myhour <- unique(tweetData$created)
  tmp <- tweetData
  score <- numeric(0)
  for(i in 1:length(myhour)){
    if(i==1){
      score <- mean(head(tmp$score,window))
    }else if (i==length(myhour)){
      score <- c(score,0)
    }else{
      score <- c(score,mean(head(tmp$score[!tmp$created %in% myhour[1:i]],window)))
    }
  }
  
  mySUM <- data.frame(created=myhour,V1=score)
  
  pp <- ggplot(data=mySUM, aes(x=created,y=V1,group=1)) + geom_hline(aes(yintercept=0),linetype='dotted')
  pp <- pp + geom_line(size=1.5) + xlab('Time of Analysis') + ylab('Overall Sentiment') + 
    opts(title=paste('Last',window,'Tweets of the',timeframe))
  pp
  #return(mySUM)
}
