#' RevoTwitterPackage
#'
#' \tabular{ll}{
#' Package: \tab RevoTwitter\cr
#' Type: \tab Package\cr
#' Version: \tab 0.0.1\cr
#' Date: \tab 2012-10-30\cr
#' License: \tab GPL (>=2)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' This package provides all the necessary R tools for ActiveCitizen SG
#'
#' @name RevoTwitter-package
#' @aliases RevoTwitter
#' @docType package
#' @title Toolkit for ActiveCitizen SG
#' @author Julian Lee \email{julian.lee@@revolutionanalytics.com}
#' @keywords package
NULL
